Copy the PLG file to the directory /boot/plugins on your unRAID server.

Issue the command: installplg /boot/plugins/dynamix.webGui-2.2.9-noarch-bergware.plg
