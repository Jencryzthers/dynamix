Copy the PLG file to the directory /boot/config/plugins on your unRAID server.

Issue the command: installplg /boot/config/plugins/dynamix.plugin.control-2.1.2-noarch-bergware.plg
